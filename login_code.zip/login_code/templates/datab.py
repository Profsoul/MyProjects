import mysql.connector

my_data = mysql.connector.connect(user = 'root',host = 'localhost', passwd = 'Manish28#',port = '3306')

my_cursor = my_data.cursor()

for i in my_cursor.fetchall():
    print(i)
