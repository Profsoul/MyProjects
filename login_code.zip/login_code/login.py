from flask import Flask,render_template,redirect,url_for,request
from flask_mysqldb import MySQL
import pandas as pd

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'USER_HOST_NAME'
app.config['MYSQL_USER'] = 'USER_NAME'
app.config['MYSQL_PASSWORD'] = 'SQL_PASSWORD'
app.config['MYSQL_DB'] = 'SQL_DATABASE'

mysql = MySQL(app)


@app.route('/')
def lo():
    return render_template("test_soul.html")

@app.route('/login')
def hello():
    return render_template("test_soul.html")

@app.route('/validation',methods = ['POST'])
def valid():
    
    mail = request.form['mail']
    pasd = request.form['pasd']
    cr = mysql.connection.cursor()
    cr.execute('SELECT column_name1,column_name2 from tablename where email = "{}"'.format(mail)) #column_name1 contains password and the column_name2 contain name of the user
    mysql.connection.commit()
    for i in cr:
        if pasd == i[0]:
            return 'welcome home {}'.format(i[1])
        else:
            return 'Invalid Password or Email'
    cr.close()
    return '<center><h1>No mailId are found please register your account</h1></center>'
   
    
@app.route('/signup')
def sign():
    return render_template("new_soul.html")

@app.route('/confirmation',methods = ['POST'])
def confirm():
    name = request.form['name']
    mail = request.form['email']
    pass1 = request.form['pass']
    pass2 = request.form['repass']
    if pass1 == pass2:
        cursor = mysql.connection.cursor()
        cursor.execute('INSERT INTO data VALUES(%s,%s,%s)',(name,mail,pass1))#Create a table contains name,email and password field.
        mysql.connection.commit()
        cursor.close()
        return redirect(url_for('hello'))
    else:
        return "<center><h3>Please Enter Same  Password!!!</h3></center>"

app.run(debug =True)


'''
 #The above code is developed by flask fraamework which is used for the purpose of the login
 # Before running the code you must have a basic konwledge of HTML,CSS,pytohn and mysql for understanding how the code is work

   ///////////Soul Corporation////////////

Contact us @profsoul23@gmail.com

'''
