from django.apps import AppConfig


class FlameConfig(AppConfig):
    name = 'flame'
