from django.shortcuts import render
from django.http import HttpResponse
from .models import info
# Create your views here.
def home(request):
    return render(request, 'intro.html')
def result(request):
    info1 = info()
    d = request.POST['ename']
    f = request.POST['pname']
    info1.fname = d
    info1.lname = f
    d = d.lower()
    f = f.lower()
    p1 = list(d)
    p2 = list(f)
    d, f = '', ''
    i = 0
    if ' ' in p1:
        p1.remove(' ')
    if ' ' in p2:
        p2.remove(' ')
    d =d.join(p1)
    f = f.join(p2)
    if d.isalpha() and f.isalpha():
        def calc(p1, p2):
            for i in p1:
                if i != '':
                    if i in p2:
                        p1.remove(i)
                        p2.remove(i)
            return p1,p2
        while (i <= 3):
            calc(p1, p2)
            p1, p2 = calc(p1, p2)
            i += 1
        p = len(p1) + len(p2)
        J = 0
        L = ["FRIENDS", "LOVE", "AFFECTION", "MARRIAGE", "ENEMY", "SISTER"]
        while len(L) > 1:
            for i in range(p):
                J += 1
                if J > len(L):
                    J = 1
            L.remove(L[J - 1])
            J -= 1
        info1.rst = L[0]
        inf = info(rst=L[0])
        inf.fname = request.POST.get('ename')
        inf.lname = request.POST.get('pname')
        inf.save()
        if L[0] == 'FRIENDS':
            p = "“True friends are always together in spirit.” “Two things you will never have to chase: True friends & true love.” “True friends are those who came into your life, saw the most negative part of you, but are not ready to leave you, no matter how contagious you are to them.”"
            return render(request, 'result.html', {'rest': L[0], 'val': p})
        elif L[0] == 'LOVE':
            p = "Staying in love and maintaining a relationship is a daily effort and doesn’t end at “I love you.” Subtly reminding your partner that you are still in love with them signals that they are desired and that the chemistry between you two is thriving."
            return render(request,'result.html', {'rest': L[0], 'val': p})
        elif L[0] == 'AFFECTION':
            p = "Affection can mean anything from handholding to lovemaking. In fact, some men can most easily express their feelings during lovemaking. That's because after being intimate they feel as though they've loved you, and often feel loved as well."
            return render(request, 'result.html', {'rest': L[0], 'val': p})
        elif L[0] == 'MARRIAGE':
            p = "A marriage is just loving relation between two persons who lead normal life full of love,trust and sacrifice with special bond or knot made of one scarf"
            return render(request, 'result.html', {'rest': L[0], 'val': p})
        elif L[0] == 'ENEMY':
            p = "An enemy is a person who actively opposes someone or something. The Latin word inimicus, meaning \"hostile, unfriendly,\" is the root of enemy, and it comes \"from the prefix in-, or \"not,\" and amicus, friend: an enemy is \"not a friend. When two armies fight each other, they both think of the opposing army as the enemy."
            return render(request, 'result.html', {'rest': L[0], 'val': p})
        elif L[0] == 'SISTER':
            p = "Your friends will come and go, but you will always have your sister. And I promise that someday-she will be your best friend.\" On being there in the good times and the bad. \"You are the person who holds me in my bad times, you are the person who dances with me in my happiness"
            return render(request, 'result.html', {'rest': L[0], 'val': p})
        else:
            return HttpResponse('Go Back and refresh page and then enter the value correctly')
    else:
        return render(request, 'error.html',{'name':d})